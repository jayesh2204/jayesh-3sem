let a = prompt("ENTER YOUR NAME")
document.write("HELLO"," ",a)